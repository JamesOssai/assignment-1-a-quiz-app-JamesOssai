package work.nbcc.rickandmorty

data class Question (var question: Int, var answer: Boolean){

}